"""Verify the delivery offline, without model weights or external dependencies."""
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
RUN = ROOT / 'results/challenge-full-20261103'

def require(condition, message):
    if not condition:
        raise ValueError(message)

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))

def read_rows(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]

def attempts(records, index, tasks):
    grouped = defaultdict(list)
    for row in records:
        grouped[row['task_id']].append(row[index])
    require(len(grouped) == tasks, f'Wrong task count: {len(grouped)}')
    require(all(sorted(indices) == list(range(8)) for indices in grouped.values()), 'Duplicate or missing attempts')

def canonical_metrics(metrics):
    return sorted(metrics, key=lambda r: (r['model'], r['size'], r['level']))

def main():
    checked = 0
    for line in (ROOT / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
        expected, relative = line.split('  ', 1)
        path = (ROOT / relative).resolve()
        require(path.is_relative_to(ROOT), 'Invalid manifest path')
        require(path.is_file() and sha256(path.read_bytes()).hexdigest() == expected, f'Hash mismatch: {relative}')
        checked += 1
    print(f'OK: SHA-256 of {checked} files')
    snapshot = read_json(RUN / 'snapshot.json')
    for name, expected in snapshot['source_hashes_frozen'].items():
        require(sha256((RUN / 'source' / name).read_bytes()).hexdigest() == expected, f'Frozen source changed: {name}')
    require(read_json(RUN / 'pipeline-status.json')['status'] == 'complete', 'Pipeline is not complete')
    teacher = read_rows(RUN / 'traces-9b/candidates.jsonl')
    require(len(teacher) == 3600, 'Expected 3600 teacher candidates')
    require(len({r['candidate_id'] for r in teacher}) == 3600, 'Duplicate candidate IDs')
    attempts(teacher, 'attempt', 450)
    baseline_files = sorted((RUN / 'baseline').glob('*-nothinking.jsonl'))
    require(len(baseline_files) == 2, 'Expected two baselines')
    expected_eval = {r['id'] for r in read_rows(RUN / 'input/eval.jsonl')}
    for path in baseline_files:
        samples = read_rows(path)
        require(len(samples) == 720, f'Expected 720 samples: {path.name}')
        require(all(r['split'] == 'eval' for r in samples), 'Unexpected test/train baseline sample')
        require({r['task_id'] for r in samples} == expected_eval, 'Baseline task set mismatch')
        attempts(samples, 'sample', 90)
    print('OK: 3600 teacher + 720/720 baseline samples; no missing/duplicate attempts; eval only')
    with tempfile.TemporaryDirectory(prefix='sudoku-offline-audit-') as tmp:
        out = Path(tmp) / 'audit.json'
        cmd = [sys.executable, '-B', '-S', str(RUN / 'source/audit.py'),
               '--dataset', str(RUN / 'input'), '--traces', str(RUN / 'traces-9b'),
               '--baselines', *(str(p) for p in baseline_files), '--out', str(out)]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode:
            raise RuntimeError('Frozen audit failed:\n' + result.stderr + result.stdout)
        audited = read_json(out)
    require(audited['artifacts_complete_for_selected_scope'] and not audited['artifact_gaps'], 'Audit has gaps')
    require((audited['traces']['sft'], audited['traces']['dpo']) == (161, 600), 'Export counts changed')
    require(canonical_metrics(audited['baseline']['metrics']) == canonical_metrics(read_json(RUN / 'metrics.json')), 'Metrics differ from re-audit')
    print('OK: all rewards reverified; 161 SFT and 600 DPO pairs; final metrics match')
    print('Delivery verified. No model weights loaded or trained.')

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(f'FAILED: {exc}', file=sys.stderr)
        raise SystemExit(1)
